# Quality KPI Tracking System / 品質KPI追跡システム

A React-based KPI data entry system for quality management.

## 🚀 Quick Start / クイックスタート

### Prerequisites / 前提条件
- Node.js 18+ installed
- npm or yarn

### Installation / インストール

```bash
# 1. Navigate to project folder
cd kpi-tracker

# 2. Install dependencies
npm install

# 3. Start development server
npm run dev
```

Then open http://localhost:3000 in your browser.

## 📁 Project Structure / プロジェクト構成

```
kpi-tracker/
├── src/
│   ├── components/
│   │   ├── LoginPage.jsx      # Login page component
│   │   ├── LoginPage.css
│   │   ├── MainPage.jsx       # Main data entry page
│   │   ├── MainPage.css
│   │   ├── Sidebar.jsx        # Category navigation
│   │   ├── Sidebar.css
│   │   ├── DataTable.jsx      # KPI data table
│   │   └── DataTable.css
│   ├── data/
│   │   └── kpiData.js         # KPI definitions & categories
│   ├── App.jsx                # Root component
│   ├── App.css
│   ├── index.css              # Global styles & CSS variables
│   └── main.jsx               # Entry point
├── index.html
├── package.json
├── vite.config.js
└── README.md
```

## ✨ Features / 機能

- 🔐 **Login with Business Unit selection** / 事業単位選択によるログイン
- 📊 **KPI data entry with auto-calculation** / 自動計算付きKPIデータ入力
- 🗂️ **Category filtering** / カテゴリフィルタリング
- 📈 **Real-time completion rate tracking** / リアルタイム完成率追跡
- 💾 **Save draft & Submit** / 下書き保存と提出
- 📤 **Export to JSON** / JSONエクスポート

## 🛠️ Customization / カスタマイズ

### Add new KPI indicators / 新しいKPI指標を追加
Edit `src/data/kpiData.js`:

```javascript
{
  code: '5-1',
  category: 'New Category',
  indicator: 'New indicator name',
  indicatorJa: '新しい指標名',
  unit: '%',
  isAuto: false
}
```

### Add new Business Units / 事業単位を追加
Edit `src/data/kpiData.js`:

```javascript
{ code: 'X1', name: 'New Business Unit' }
```

### Change colors / 色を変更
Edit CSS variables in `src/index.css`:

```css
:root {
  --color-primary: #3B82F6;  /* Main brand color */
  --color-primary-hover: #2563EB;
  ...
}
```

## 🔧 Build for Production / 本番ビルド

```bash
npm run build
```

Output will be in the `dist/` folder.

## 📝 Next Steps / 次のステップ

1. **Connect to Backend API** - Replace localStorage/alerts with real API calls
2. **Add authentication** - Implement proper login with JWT
3. **Add data persistence** - Connect to database (SharePoint, SQL, etc.)
4. **Add charts** - Visualize KPI trends with Chart.js or Recharts

## 📄 License

Internal use only / 社内使用のみ
