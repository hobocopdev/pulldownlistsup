import { useState } from 'react'
import { LanguageProvider } from './hooks/useLanguage'
import LoginPage from './components/LoginPage'
import MainPage from './components/MainPage'
import './App.css'

function App() {
  const [isLoggedIn, setIsLoggedIn] = useState(false)
  const [userInfo, setUserInfo] = useState({
    businessUnit: '',
    role: 'user'
  })

  const handleLogin = (businessUnit, role) => {
    setUserInfo({ businessUnit, role })
    setIsLoggedIn(true)
  }

  const handleLogout = () => {
    setIsLoggedIn(false)
    setUserInfo({ businessUnit: '', role: 'user' })
  }

  return (
    <LanguageProvider>
      <div className="app">
        {!isLoggedIn ? (
          <LoginPage onLogin={handleLogin} />
        ) : (
          <MainPage userInfo={userInfo} onLogout={handleLogout} />
        )}
      </div>
    </LanguageProvider>
  )
}

export default App
