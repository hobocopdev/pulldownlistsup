import { useState } from 'react'
import { useLanguage } from '../hooks/useLanguage'
import Sidebar from './Sidebar'
import DataTable from './DataTable'
import { kpiData } from '../data/kpiData'
import './MainPage.css'

function MainPage({ userInfo, onLogout }) {
  const { t } = useLanguage()
  const [activeCategory, setActiveCategory] = useState('all')
  const [values, setValues] = useState(() => {
    return kpiData.reduce((acc, item) => {
      acc[item.code] = { 
        target: '', 
        result: '', 
        unit: item.unit,
        reason: '' 
      }
      return acc
    }, {})
  })
  const [status, setStatus] = useState('draft')

  // 根据分类筛选数据
  const filteredData = activeCategory === 'all'
    ? kpiData
    : kpiData.filter(item => item.category === activeCategory)

  // 计算完成率
  const calculateCompletionRate = () => {
    const editableItems = kpiData.filter(item => !item.isAuto)
    const filledItems = editableItems.filter(item => {
      const v = values[item.code]
      return v && v.target !== '' && v.result !== ''
    })
    return Math.round((filledItems.length / editableItems.length) * 100)
  }

  // 计算自动计算项的值
  const calculateAutoValues = () => {
    const complaintsSum = ['2-1', '2-2', '2-3', '2-4'].reduce((sum, code) => {
      const val = parseFloat(values[code]?.result) || 0
      return sum + val
    }, 0)

    const costSum = ['4-1', '4-2', '4-3', '4-4'].reduce((sum, code) => {
      const val = parseFloat(values[code]?.result) || 0
      return sum + val
    }, 0)

    return {
      '2-5': { target: '—', result: complaintsSum.toFixed(2) },
      '4-5': { target: '—', result: costSum.toFixed(2) }
    }
  }

  const autoValues = calculateAutoValues()

  // 检查是否未达标
  const checkNotAchieved = (code) => {
    const item = kpiData.find(k => k.code === code)
    if (!item) return false
    
    const target = parseFloat(values[code]?.target)
    const result = parseFloat(values[code]?.result)
    
    if (isNaN(target) || isNaN(result)) return false
    
    if (item.lowerIsBetter) {
      return result > target // 实际 > 目标 = 未达标
    } else {
      return result < target // 实际 < 目标 = 未达标
    }
  }

  // 更新值
  const handleValueChange = (code, field, value) => {
    setValues(prev => ({
      ...prev,
      [code]: { ...prev[code], [field]: value }
    }))
  }

  // 保存草稿
  const handleSaveDraft = () => {
    alert(t('draftSaved'))
  }

  // 提交数据
  const handleSubmit = () => {
    // 检查需要原因的指标
    const itemsNeedingReason = kpiData.filter(item => item.requiresReason)
    
    for (const item of itemsNeedingReason) {
      if (checkNotAchieved(item.code)) {
        if (!values[item.code]?.reason) {
          alert(t('reasonRequiredAlert', { code: item.code }))
          return
        }
      }
    }
    
    const completionRate = calculateCompletionRate()
    if (completionRate < 100) {
      if (!confirm(t('confirmSubmit', { rate: completionRate }))) {
        return
      }
    }
    
    setStatus('submitted')
    alert(t('dataSubmitted'))
  }

  // 导出数据
  const handleExport = () => {
    const exportData = kpiData.map(item => ({
      code: item.code,
      category: item.category,
      indicator: item.indicator.en,
      target: values[item.code]?.target || '',
      result: values[item.code]?.result || '',
      unit: values[item.code]?.unit || item.unit,
      reason: values[item.code]?.reason || ''
    }))
    
    const blob = new Blob([JSON.stringify(exportData, null, 2)], { type: 'application/json' })
    const url = URL.createObjectURL(blob)
    const a = document.createElement('a')
    a.href = url
    a.download = `kpi-data-${userInfo.businessUnit}-${new Date().toISOString().slice(0,10)}.json`
    a.click()
  }

  return (
    <div className="main-page">
      <Sidebar
        activeCategory={activeCategory}
        onCategoryChange={setActiveCategory}
        completionRate={calculateCompletionRate()}
        userInfo={userInfo}
        onLogout={onLogout}
      />
      
      <main className="main-content">
        {/* Header */}
        <header className="page-header">
          <div className="header-left">
            <h1>{t('dataEntry')}</h1>
            <div className="header-meta">
              <span>{t('businessUnit')}: {userInfo.businessUnit}</span>
              <span className="separator">•</span>
              <span>{t('period')}: {new Date().toLocaleDateString('en-US', { month: 'long', year: 'numeric' })}</span>
              <span className="separator">•</span>
              <span className={`status-badge ${status}`}>
                {status === 'draft' ? t('draft') : t('submitted')}
              </span>
            </div>
          </div>
          
          <div className="header-actions">
            <button className="btn" onClick={() => alert(t('importComingSoon'))}>
              <span>↑</span> {t('import')}
            </button>
            <button className="btn" onClick={handleExport}>
              <span>↓</span> {t('export')}
            </button>
            <button className="btn" onClick={handleSaveDraft}>
              <span>💾</span> {t('saveDraft')}
            </button>
            <button className="btn btn-primary" onClick={handleSubmit}>
              <span>✓</span> {t('submit')}
            </button>
          </div>
        </header>

        {/* Data Table */}
        <DataTable
          data={filteredData}
          values={values}
          autoValues={autoValues}
          onValueChange={handleValueChange}
          checkNotAchieved={checkNotAchieved}
        />
      </main>
    </div>
  )
}

export default MainPage
