import { useState } from 'react'
import { useLanguage } from '../hooks/useLanguage'
import { businessUnits } from '../data/kpiData'
import LanguageSwitcher from './LanguageSwitcher'
import './LoginPage.css'

function LoginPage({ onLogin }) {
  const { t } = useLanguage()
  const [selectedUnit, setSelectedUnit] = useState('')
  const [password, setPassword] = useState('')
  const [role, setRole] = useState('user')
  const [error, setError] = useState('')

  const handleSubmit = (e) => {
    e.preventDefault()
    
    if (!selectedUnit) {
      setError(t('pleaseSelectUnit'))
      return
    }
    
    if (password.length < 1) {
      setError(t('pleaseEnterPassword'))
      return
    }
    
    onLogin(selectedUnit, role)
  }

  return (
    <div className="login-page">
      <div className="login-language">
        <LanguageSwitcher />
      </div>
      
      <div className="login-card">
        {/* Logo */}
        <div className="login-logo">
          <svg viewBox="0 0 24 24" fill="currentColor">
            <rect x="3" y="3" width="7" height="7" rx="1"/>
            <rect x="14" y="3" width="7" height="7" rx="1"/>
            <rect x="3" y="14" width="7" height="7" rx="1"/>
            <rect x="14" y="14" width="7" height="7" rx="1"/>
          </svg>
        </div>

        {/* Title */}
        <h1 className="login-title">{t('appTitle')}</h1>
        <p className="login-subtitle">{t('appSubtitle')}</p>

        {/* Form */}
        <form onSubmit={handleSubmit} className="login-form">
          {/* Business Unit */}
          <div className="form-group">
            <label className="form-label">
              {t('businessUnit')}
            </label>
            <select 
              className="input"
              value={selectedUnit}
              onChange={(e) => {
                setSelectedUnit(e.target.value)
                setError('')
              }}
            >
              <option value="">{t('selectBusinessUnit')}</option>
              {businessUnits.map(unit => (
                <option key={unit.code} value={unit.code}>
                  {unit.code} - {unit.name}
                </option>
              ))}
            </select>
          </div>

          {/* Password */}
          <div className="form-group">
            <label className="form-label">
              {t('password')}
            </label>
            <input
              type="password"
              className="input"
              placeholder={t('enterPassword')}
              value={password}
              onChange={(e) => {
                setPassword(e.target.value)
                setError('')
              }}
            />
          </div>

          {/* Role Toggle */}
          <div className="form-group">
            <label className="form-label">
              {t('loginAs')}
            </label>
            <div className="role-toggle">
              <button
                type="button"
                className={`role-btn ${role === 'user' ? 'active' : ''}`}
                onClick={() => setRole('user')}
              >
                {t('user')}
              </button>
              <button
                type="button"
                className={`role-btn ${role === 'admin' ? 'active' : ''}`}
                onClick={() => setRole('admin')}
              >
                {t('admin')}
              </button>
            </div>
          </div>

          {/* Error Message */}
          {error && <div className="error-message">{error}</div>}

          {/* Submit Button */}
          <button type="submit" className="login-btn">
            {t('login')}
          </button>
        </form>

        <p className="login-footer">{t('internalUseOnly')}</p>
      </div>
    </div>
  )
}

export default LoginPage
