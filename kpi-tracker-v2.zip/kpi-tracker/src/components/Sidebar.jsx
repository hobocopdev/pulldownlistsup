import { useLanguage } from '../hooks/useLanguage'
import { categories, categoryNames } from '../data/kpiData'
import LanguageSwitcher from './LanguageSwitcher'
import './Sidebar.css'

function Sidebar({ activeCategory, onCategoryChange, completionRate, userInfo, onLogout }) {
  const { lang, t } = useLanguage()

  return (
    <aside className="sidebar">
      {/* Logo and Title */}
      <div className="sidebar-header">
        <div className="sidebar-logo">
          <svg viewBox="0 0 24 24" fill="currentColor">
            <rect x="3" y="3" width="7" height="7" rx="1"/>
            <rect x="14" y="3" width="7" height="7" rx="1"/>
            <rect x="3" y="14" width="7" height="7" rx="1"/>
            <rect x="14" y="14" width="7" height="7" rx="1"/>
          </svg>
        </div>
        <div className="sidebar-info">
          <div className="sidebar-title">KPI Tracker</div>
          <div className="sidebar-period">FY2025 Q1</div>
        </div>
      </div>

      {/* Language Switcher */}
      <div className="sidebar-section">
        <div className="section-label">{t('language')}</div>
        <LanguageSwitcher />
      </div>

      {/* Categories */}
      <div className="sidebar-section">
        <div className="section-label">{t('categories')}</div>
        <ul className="category-list">
          {categories.map(cat => (
            <li
              key={cat.id}
              className={`category-item ${activeCategory === cat.id ? 'active' : ''}`}
              onClick={() => onCategoryChange(cat.id)}
            >
              <span className="category-icon">{cat.icon}</span>
              <span className="category-name">{categoryNames[cat.id][lang]}</span>
            </li>
          ))}
        </ul>
      </div>

      {/* Completion Rate */}
      <div className="sidebar-section">
        <div className="completion-box">
          <div className="completion-label">{t('completionRate')}</div>
          <div className="completion-value">{completionRate}%</div>
          <div className="completion-bar">
            <div 
              className="completion-fill" 
              style={{ width: `${completionRate}%` }}
            />
          </div>
        </div>
      </div>

      {/* User Info */}
      <div className="sidebar-footer">
        <div className="user-info">
          <div className="user-avatar">
            {userInfo.businessUnit}
          </div>
          <div className="user-details">
            <div className="user-unit">Unit {userInfo.businessUnit}</div>
            <div className="user-role">{userInfo.role === 'admin' ? t('admin') : t('user')}</div>
          </div>
        </div>
        <button className="logout-btn" onClick={onLogout}>
          {t('logout')}
        </button>
      </div>
    </aside>
  )
}

export default Sidebar
