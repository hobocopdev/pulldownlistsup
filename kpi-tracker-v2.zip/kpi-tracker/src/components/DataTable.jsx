import { useLanguage } from '../hooks/useLanguage'
import { currencyUnits, notAchievedReasons } from '../data/translations'
import { categoryNames } from '../data/kpiData'
import './DataTable.css'

function DataTable({ data, values, autoValues, onValueChange, checkNotAchieved }) {
  const { lang, t } = useLanguage()

  // 获取状态
  const getStatus = (code, isAuto, requiresReason) => {
    if (isAuto) return 'auto'
    
    const v = values[code]
    const hasValues = v && v.target !== '' && v.result !== ''
    
    if (!hasValues) return 'pending'
    
    // 检查是否未达标
    if (checkNotAchieved(code)) {
      return 'notAchieved'
    }
    
    return 'done'
  }

  // 获取状态文本
  const getStatusText = (status) => {
    switch (status) {
      case 'pending': return t('pending')
      case 'done': return t('done')
      case 'auto': return t('auto')
      case 'notAchieved': return t('notAchieved')
      default: return status
    }
  }

  // 获取显示值
  const getDisplayValue = (code, field) => {
    if (autoValues[code]) {
      return autoValues[code][field]
    }
    return values[code]?.[field] || ''
  }

  return (
    <div className="table-container">
      <table className="data-table">
        <thead>
          <tr>
            <th style={{ width: '70px' }}>{t('code')}</th>
            <th style={{ width: '120px' }}>{t('category')}</th>
            <th>{t('indicator')}</th>
            <th style={{ width: '100px' }}>{t('target')}</th>
            <th style={{ width: '100px' }}>{t('result')}</th>
            <th style={{ width: '90px' }}>{t('unit')}</th>
            <th style={{ width: '80px' }}>{t('status')}</th>
            <th style={{ width: '140px' }}>{t('reason')}</th>
          </tr>
        </thead>
        <tbody>
          {data.map(item => {
            const status = getStatus(item.code, item.isAuto, item.requiresReason)
            const showReasonField = item.requiresReason && status === 'notAchieved'
            
            return (
              <tr key={item.code} className={item.isAuto ? 'auto-row' : ''}>
                <td className="code-cell">{item.code}</td>
                <td className="category-cell">{categoryNames[item.category]?.[lang]}</td>
                <td className="indicator-cell">
                  {item.indicator[lang]}
                  {item.isAuto && (
                    <span className="auto-note">({t('auto')})</span>
                  )}
                </td>
                <td className="input-cell">
                  <input
                    type="number"
                    step="0.01"
                    placeholder="0.00"
                    value={getDisplayValue(item.code, 'target')}
                    onChange={(e) => onValueChange(item.code, 'target', e.target.value)}
                    disabled={item.isAuto}
                  />
                </td>
                <td className="input-cell">
                  <input
                    type="number"
                    step="0.01"
                    placeholder="0.00"
                    value={getDisplayValue(item.code, 'result')}
                    onChange={(e) => onValueChange(item.code, 'result', e.target.value)}
                    disabled={item.isAuto}
                  />
                </td>
                <td className="unit-cell">
                  {item.unitType === 'currency' ? (
                    <select
                      className="unit-select"
                      value={values[item.code]?.unit || item.unit}
                      onChange={(e) => onValueChange(item.code, 'unit', e.target.value)}
                      disabled={item.isAuto}
                    >
                      {currencyUnits.map(u => (
                        <option key={u.value} value={u.value}>{u.label}</option>
                      ))}
                    </select>
                  ) : (
                    <span>{item.unit}</span>
                  )}
                </td>
                <td className="status-cell">
                  <span className={`status-tag ${status}`}>
                    {getStatusText(status)}
                  </span>
                </td>
                <td className="reason-cell">
                  {item.requiresReason ? (
                    showReasonField ? (
                      <select
                        className={`reason-select required ${!values[item.code]?.reason ? 'empty' : ''}`}
                        value={values[item.code]?.reason || ''}
                        onChange={(e) => onValueChange(item.code, 'reason', e.target.value)}
                      >
                        <option value="">{t('selectReason')}</option>
                        {notAchievedReasons.map(r => (
                          <option key={r.value} value={r.value}>{r.label[lang]}</option>
                        ))}
                      </select>
                    ) : (
                      <span className="reason-optional">—</span>
                    )
                  ) : (
                    <span className="reason-na">—</span>
                  )}
                </td>
              </tr>
            )
          })}
        </tbody>
      </table>
    </div>
  )
}

export default DataTable
