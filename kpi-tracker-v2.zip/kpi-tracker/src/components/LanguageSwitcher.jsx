import { useLanguage } from '../hooks/useLanguage'
import './LanguageSwitcher.css'

const languages = [
  { code: 'en', label: 'EN' },
  { code: 'ja', label: '日本語' },
  { code: 'zh', label: '中文' },
]

function LanguageSwitcher() {
  const { lang, setLang } = useLanguage()

  return (
    <div className="language-switcher">
      {languages.map((language) => (
        <button
          key={language.code}
          className={`lang-btn ${lang === language.code ? 'active' : ''}`}
          onClick={() => setLang(language.code)}
        >
          {language.label}
        </button>
      ))}
    </div>
  )
}

export default LanguageSwitcher
