// KPI 指标数据
export const kpiData = [
  { 
    code: '1-1', 
    category: 'serious',
    indicator: { 
      en: 'Critical product defects', 
      ja: '重大製品欠陥', 
      zh: '重大产品缺陷' 
    },
    unit: 'cases',
    unitType: 'fixed',
    isAuto: false,
    requiresReason: true,
    lowerIsBetter: true,
  },
  { 
    code: '1-2', 
    category: 'serious',
    indicator: { 
      en: 'Safety incidents', 
      ja: '安全インシデント', 
      zh: '安全事故' 
    },
    unit: 'cases',
    unitType: 'fixed',
    isAuto: false,
    requiresReason: false,
    lowerIsBetter: true,
  },
  { 
    code: '2-1', 
    category: 'complaints',
    indicator: { 
      en: 'Product quality complaints', 
      ja: '製品品質苦情', 
      zh: '产品质量投诉' 
    },
    unit: 'cases',
    unitType: 'fixed',
    isAuto: false,
    requiresReason: true,
    lowerIsBetter: true,
  },
  { 
    code: '2-2', 
    category: 'complaints',
    indicator: { 
      en: 'Delivery complaints', 
      ja: '納期苦情', 
      zh: '交期投诉' 
    },
    unit: 'cases',
    unitType: 'fixed',
    isAuto: false,
    requiresReason: false,
    lowerIsBetter: true,
  },
  { 
    code: '2-3', 
    category: 'complaints',
    indicator: { 
      en: 'Service complaints', 
      ja: 'サービス苦情', 
      zh: '服务投诉' 
    },
    unit: 'cases',
    unitType: 'fixed',
    isAuto: false,
    requiresReason: false,
    lowerIsBetter: true,
  },
  { 
    code: '2-4', 
    category: 'complaints',
    indicator: { 
      en: 'Documentation issues', 
      ja: 'ドキュメント問題', 
      zh: '文档问题' 
    },
    unit: 'cases',
    unitType: 'fixed',
    isAuto: false,
    requiresReason: false,
    lowerIsBetter: true,
  },
  { 
    code: '2-5', 
    category: 'complaints',
    indicator: { 
      en: 'Total complaints (calculated)', 
      ja: '苦情合計（自動計算）', 
      zh: '投诉合计（自动计算）' 
    },
    unit: 'cases',
    unitType: 'fixed',
    isAuto: true,
    requiresReason: false,
    lowerIsBetter: true,
  },
  { 
    code: '3-1', 
    category: 'response',
    indicator: { 
      en: 'First response rate', 
      ja: '初回回答率', 
      zh: '首次响应率' 
    },
    unit: '%',
    unitType: 'fixed',
    isAuto: false,
    requiresReason: false,
    lowerIsBetter: false,
  },
  { 
    code: '3-2', 
    category: 'response',
    indicator: { 
      en: 'Resolution rate', 
      ja: '解決率', 
      zh: '解决率' 
    },
    unit: '%',
    unitType: 'fixed',
    isAuto: false,
    requiresReason: false,
    lowerIsBetter: false,
  },
  { 
    code: '3-3', 
    category: 'response',
    indicator: { 
      en: 'On-time closure rate', 
      ja: '期限内クローズ率', 
      zh: '按时关闭率' 
    },
    unit: '%',
    unitType: 'fixed',
    isAuto: false,
    requiresReason: true,
    lowerIsBetter: false,
  },
  { 
    code: '4-1', 
    category: 'cost',
    indicator: { 
      en: 'Internal failure cost', 
      ja: '内部失敗コスト', 
      zh: '内部失败成本' 
    },
    unit: 'MJPY',
    unitType: 'currency',
    isAuto: false,
    requiresReason: false,
    lowerIsBetter: true,
  },
  { 
    code: '4-2', 
    category: 'cost',
    indicator: { 
      en: 'External failure cost', 
      ja: '外部失敗コスト', 
      zh: '外部失败成本' 
    },
    unit: 'MJPY',
    unitType: 'currency',
    isAuto: false,
    requiresReason: false,
    lowerIsBetter: true,
  },
  { 
    code: '4-3', 
    category: 'cost',
    indicator: { 
      en: 'Prevention cost', 
      ja: '予防コスト', 
      zh: '预防成本' 
    },
    unit: 'MJPY',
    unitType: 'currency',
    isAuto: false,
    requiresReason: true,
    lowerIsBetter: true,
  },
  { 
    code: '4-4', 
    category: 'cost',
    indicator: { 
      en: 'Appraisal cost', 
      ja: '評価コスト', 
      zh: '评估成本' 
    },
    unit: 'MJPY',
    unitType: 'currency',
    isAuto: false,
    requiresReason: false,
    lowerIsBetter: true,
  },
  { 
    code: '4-5', 
    category: 'cost',
    indicator: { 
      en: 'Total quality cost (calculated)', 
      ja: '品質コスト合計（自動計算）', 
      zh: '质量成本合计（自动计算）' 
    },
    unit: 'MJPY',
    unitType: 'currency',
    isAuto: true,
    requiresReason: false,
    lowerIsBetter: true,
  },
  { 
    code: '4-6', 
    category: 'cost',
    indicator: { 
      en: 'Cost of poor quality ratio', 
      ja: '品質不良コスト比率', 
      zh: '不良质量成本比率' 
    },
    unit: '%',
    unitType: 'fixed',
    isAuto: false,
    requiresReason: true,
    lowerIsBetter: true,
  },
]

// 分类列表
export const categories = [
  { id: 'all', icon: '📋' },
  { id: 'serious', icon: '⚠️' },
  { id: 'complaints', icon: '💬' },
  { id: 'response', icon: '📈' },
  { id: 'cost', icon: '💰' },
]

// 分类名称（多语言）
export const categoryNames = {
  all: { en: 'All', ja: '全て', zh: '全部' },
  serious: { en: 'Serious Complaints', ja: '重大苦情', zh: '重大投诉' },
  complaints: { en: 'Complaints', ja: '苦情', zh: '投诉' },
  response: { en: 'Response Rate', ja: '回答率', zh: '响应率' },
  cost: { en: 'Quality Cost', ja: '品質コスト', zh: '质量成本' },
}

// 事业单位列表
export const businessUnits = [
  { code: 'A1', name: 'Passive Components BG' },
  { code: 'B5', name: 'Sensor Systems BG' },
  { code: 'L2', name: 'Energy Devices BG' },
  { code: 'C3', name: 'Magnetic Application Products BG' },
  { code: 'E1', name: 'Energy Devices BG' },
]
