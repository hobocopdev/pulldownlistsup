// 多语言翻译文件
export const translations = {
  en: {
    // Login Page
    appTitle: 'Quality KPI Tracking System',
    appSubtitle: 'Quality KPI Tracking System',
    businessUnit: 'Business Unit',
    password: 'Password',
    enterPassword: 'Enter password',
    selectBusinessUnit: 'Select Business Unit...',
    loginAs: 'Login as',
    user: 'User',
    admin: 'Admin',
    login: 'Login',
    internalUseOnly: 'For internal use only',
    
    // Validation
    pleaseSelectUnit: 'Please select a Business Unit',
    pleaseEnterPassword: 'Please enter password',
    
    // Main Page
    dataEntry: 'Quality KPI Data Entry',
    period: 'Period',
    draft: 'Draft',
    submitted: 'Submitted',
    import: 'Import',
    export: 'Export',
    saveDraft: 'Save Draft',
    submit: 'Submit',
    
    // Sidebar
    categories: 'Categories',
    all: 'All',
    seriousComplaints: 'Serious Complaints',
    complaints: 'Complaints',
    responseRate: 'Response Rate',
    qualityCost: 'Quality Cost',
    completionRate: 'Completion Rate',
    logout: 'Logout',
    
    // Table
    code: 'Code',
    category: 'Category',
    indicator: 'Indicator',
    target: 'Target',
    result: 'Result',
    unit: 'Unit',
    status: 'Status',
    reason: 'Reason',
    
    // Status
    pending: 'Pending',
    done: 'Done',
    auto: 'Auto',
    notAchieved: 'Not Achieved',
    
    // Units
    selectCurrency: 'Select currency',
    
    // Reasons
    selectReason: 'Select reason...',
    reasonRequired: 'Reason required',
    
    // Messages
    draftSaved: 'Draft saved!',
    dataSubmitted: 'Data submitted!',
    confirmSubmit: 'Completion rate is {rate}%. Submit anyway?',
    reasonRequiredAlert: '{code} did not achieve target. Please select a reason.',
    importComingSoon: 'Import feature coming soon',
    
    // Language
    language: 'Language',
  },
  
  ja: {
    // Login Page
    appTitle: 'Quality KPI Tracking System',
    appSubtitle: '品質KPI追跡システム',
    businessUnit: '事業単位',
    password: 'パスワード',
    enterPassword: 'パスワードを入力',
    selectBusinessUnit: '事業単位を選択...',
    loginAs: 'ログインタイプ',
    user: 'ユーザー',
    admin: '管理者',
    login: 'ログイン',
    internalUseOnly: '社内使用のみ',
    
    // Validation
    pleaseSelectUnit: '事業単位を選択してください',
    pleaseEnterPassword: 'パスワードを入力してください',
    
    // Main Page
    dataEntry: '品質KPIデータ入力',
    period: '期間',
    draft: '下書き',
    submitted: '提出済み',
    import: 'インポート',
    export: 'エクスポート',
    saveDraft: '下書き保存',
    submit: '提出',
    
    // Sidebar
    categories: 'カテゴリ',
    all: '全て',
    seriousComplaints: '重大苦情',
    complaints: '苦情',
    responseRate: '回答率',
    qualityCost: '品質コスト',
    completionRate: '完成率',
    logout: 'ログアウト',
    
    // Table
    code: 'コード',
    category: 'カテゴリ',
    indicator: '指標',
    target: '目標',
    result: '実績',
    unit: '単位',
    status: 'ステータス',
    reason: '理由',
    
    // Status
    pending: '未入力',
    done: '完了',
    auto: '自動',
    notAchieved: '未達成',
    
    // Units
    selectCurrency: '通貨を選択',
    
    // Reasons
    selectReason: '理由を選択...',
    reasonRequired: '理由必須',
    
    // Messages
    draftSaved: '下書きを保存しました！',
    dataSubmitted: 'データを提出しました！',
    confirmSubmit: '完成率は{rate}%です。提出しますか？',
    reasonRequiredAlert: '{code}は未達成です。理由を選択してください。',
    importComingSoon: 'インポート機能は近日公開予定',
    
    // Language
    language: '言語',
  },
  
  zh: {
    // Login Page
    appTitle: 'Quality KPI Tracking System',
    appSubtitle: '品质KPI追踪系统',
    businessUnit: '事业单位',
    password: '密码',
    enterPassword: '请输入密码',
    selectBusinessUnit: '选择事业单位...',
    loginAs: '登录类型',
    user: '用户',
    admin: '管理员',
    login: '登录',
    internalUseOnly: '仅供内部使用',
    
    // Validation
    pleaseSelectUnit: '请选择事业单位',
    pleaseEnterPassword: '请输入密码',
    
    // Main Page
    dataEntry: '品质KPI数据录入',
    period: '期间',
    draft: '草稿',
    submitted: '已提交',
    import: '导入',
    export: '导出',
    saveDraft: '保存草稿',
    submit: '提交',
    
    // Sidebar
    categories: '分类',
    all: '全部',
    seriousComplaints: '重大投诉',
    complaints: '投诉',
    responseRate: '响应率',
    qualityCost: '质量成本',
    completionRate: '完成率',
    logout: '退出登录',
    
    // Table
    code: '编号',
    category: '分类',
    indicator: '指标',
    target: '目标',
    result: '实绩',
    unit: '单位',
    status: '状态',
    reason: '原因',
    
    // Status
    pending: '待录入',
    done: '已完成',
    auto: '自动',
    notAchieved: '未达标',
    
    // Units
    selectCurrency: '选择货币',
    
    // Reasons
    selectReason: '选择原因...',
    reasonRequired: '需填原因',
    
    // Messages
    draftSaved: '草稿已保存！',
    dataSubmitted: '数据已提交！',
    confirmSubmit: '完成率为{rate}%，确定提交吗？',
    reasonRequiredAlert: '{code}未达标，请选择原因。',
    importComingSoon: '导入功能即将上线',
    
    // Language
    language: '语言',
  }
}

// 货币单位
export const currencyUnits = [
  { value: 'MJPY', label: 'MJPY' },
  { value: 'MUSD', label: 'MUSD' },
  { value: 'MRMB', label: 'MRMB' },
  { value: 'MEUR', label: 'MEUR' },
  { value: 'MKRW', label: 'MKRW' },
]

// 未达标原因
export const notAchievedReasons = [
  { 
    value: 'material', 
    label: { en: 'Material issue', ja: '原材料問題', zh: '原材料问题' } 
  },
  { 
    value: 'process', 
    label: { en: 'Process issue', ja: '工程問題', zh: '工艺问题' } 
  },
  { 
    value: 'equipment', 
    label: { en: 'Equipment failure', ja: '設備故障', zh: '设备故障' } 
  },
  { 
    value: 'human', 
    label: { en: 'Human error', ja: 'ヒューマンエラー', zh: '人为失误' } 
  },
  { 
    value: 'supplier', 
    label: { en: 'Supplier issue', ja: 'サプライヤー問題', zh: '供应商问题' } 
  },
  { 
    value: 'design', 
    label: { en: 'Design defect', ja: '設計不良', zh: '设计缺陷' } 
  },
  { 
    value: 'external', 
    label: { en: 'External factors', ja: '外部要因', zh: '外部因素' } 
  },
  { 
    value: 'other', 
    label: { en: 'Other', ja: 'その他', zh: '其他' } 
  },
]
