import { createContext, useContext, useState } from 'react'
import { translations } from '../data/translations'

// 创建语言上下文
const LanguageContext = createContext()

// 语言 Provider 组件
export function LanguageProvider({ children }) {
  const [lang, setLang] = useState('ja') // 默认日语

  // 翻译函数
  const t = (key, replacements = {}) => {
    let text = translations[lang]?.[key] || translations['en']?.[key] || key
    
    // 替换占位符 {xxx}
    Object.entries(replacements).forEach(([k, v]) => {
      text = text.replace(`{${k}}`, v)
    })
    
    return text
  }

  const value = {
    lang,
    setLang,
    t,
  }

  return (
    <LanguageContext.Provider value={value}>
      {children}
    </LanguageContext.Provider>
  )
}

// 使用语言的 Hook
export function useLanguage() {
  const context = useContext(LanguageContext)
  if (!context) {
    throw new Error('useLanguage must be used within a LanguageProvider')
  }
  return context
}
